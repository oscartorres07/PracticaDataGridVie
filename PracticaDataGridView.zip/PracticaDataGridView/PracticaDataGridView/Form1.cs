﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PracticaDataGridView
{
    public partial class Form1 : Form
    {
        SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=ClaseTopicos;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        int id = 0;
        public Form1()
        {
            InitializeComponent();
            DisplayData();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void bt_insertar_Click(object sender, EventArgs e)
        {
            if (tb_id.Text != "" && tb_user.Text != "" && tb_password.Text !="")
            {
                cmd = new SqlCommand("insert into usuarios(id,usuario,contraseña) values(@id,@usuario,@contraseña)", cn);
                cn.Open();
                cmd.Parameters.AddWithValue("@id", tb_id.Text);
                cmd.Parameters.AddWithValue("@usuario", tb_user.Text);
                cmd.Parameters.AddWithValue("@contraseña", tb_password.Text);
                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Informacion insertada");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }
        private void DisplayData() {
            cn.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from usuarios", cn);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            cn.Close();
        }
        private void ClearData()
        {
            tb_user.Text = "";
            tb_password.Text = "";
            id = 0;
        }

        private void bt_actualizar_Click(object sender, EventArgs e)
        {
            if (tb_id.Text !="" && tb_user.Text != "" && tb_password.Text != "")
            {
                cmd = new SqlCommand("update usuarios set usuario=@usuario,contraseña=@contraseña where id=@id", cn);
                cn.Open();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@usuario", tb_user.Text);
                cmd.Parameters.AddWithValue("@contraseña", tb_password.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                cn.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
        }

        private void bt_eliminar_Click(object sender, EventArgs e)
        {
            if (id != 0)
            {
                cmd = new SqlCommand("delete usuarios where id=@id", cn);
                cn.Open();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Record Deleted Successfully!");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            tb_user.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            tb_password.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
    }
}
